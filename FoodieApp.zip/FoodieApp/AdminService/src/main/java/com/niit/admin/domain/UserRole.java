package com.niit.admin.domain;

public enum UserRole
{
    USER , ADMIN ,RESTAURANT
}
