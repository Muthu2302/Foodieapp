package com.niit.admin.domain;

public enum ApproveType {
    APPROVED, NOT_APPROVED
}