package com.niit.Authentication.Service.domain;

public enum UserRole {
    USER , ADMIN ,RESTAURANT
}
