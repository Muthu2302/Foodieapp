package com.niit.CustomerService.domain;

public enum UserRole {
    USER,ADMIN, RESTAURANT
}
