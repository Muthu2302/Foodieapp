package com.niit.RestaurantService.domain;

public enum UserRole {
    USER,ADMIN, RESTAURANT
}
