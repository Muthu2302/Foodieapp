package com.niit.RestaurantService.domain;

public enum ApproveType {
    APPROVED, NOT_APPROVED
}